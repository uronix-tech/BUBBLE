# BubbleAR — POC

אפליקציית AR לגילוי אנשים בסביבה דרך בועות דיגיטליות.

## קבצים
- `index.html` — מסך בחירה ראשי
- `broadcaster.html` — יצירת פרופיל ושידור בועה
- `scanner.html` — סריקת סביבה עם AR overlay

## הרצה מקומית (לפיתוח)
```bash
npx serve .
# ואז פתח http://localhost:3000
```

## פריסה על GitHub Pages (חינם, HTTPS נדרש לBluetooth)

1. צור repository חדש ב-GitHub
2. העלה את 3 הקבצים
3. Settings → Pages → Source: main branch
4. האתר יהיה זמין ב: `https://USERNAME.github.io/REPO/`

## הרצה על אנדרואיד
1. פתח Chrome על Android
2. נווט ל-URL מ-GitHub Pages
3. **טלפון A**: broadcaster.html — מלא פרופיל, לחץ "פתח בועה"
4. **טלפון B**: scanner.html — הפעל מצלמה, ראה בועות

## שיטת תקשורת בין מכשירים

### גרסת POC הנוכחית
- BroadcastChannel API (אותו מכשיר / tab)
- localStorage כ-"beacon" מדומה
- הדגמה אוטומטית עם פרופילים לדמו

### גרסה הבאה (production)
- Firebase Realtime DB לsync בין מכשירים
- Web Bluetooth API לגילוי BLE אמיתי
- MediaPipe Body Detection לעיגון בועות על גוף

## טכנולוגיות
- Vanilla HTML/CSS/JS (ללא framework)
- WebRTC getUserMedia (מצלמה)
- BroadcastChannel API
- Canvas AR overlay
- Web Bluetooth API (מוכן לintregration)
